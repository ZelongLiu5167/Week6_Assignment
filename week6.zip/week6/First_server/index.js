let express = require('express');
let app = express();

let endangeredAnimals = {
    "data": [
        {
            name: "Amur Tiger",
            number: "500",
            info: "The Amur tiger is distributed in the northeastern part of Asia, specifically in the Russian Far East and the Jilin and Heilongjiang provinces of northeast China, and may still survive in northern Korea. Due to habitat destruction and poaching, there are only about 500 wild Northeast tigers left in the world."
        },
        {
            name: "Black Rhino",
            number: "5000",
            info: "The black rhinoceros is primarily distributed across vast areas of eastern, central, western, and southern Africa. It mainly inhabits the mountainous regions near water sources, typically found in dense thorny shrublands or acacia thickets."
        },
        {
            name: "Mountain Gorilla",
            number: "1063",
            info: "Mountain gorillas are found in the high-altitude tropical forests of central Africa, particularly in the Virunga Mountains and Bwindi Impenetrable National Park. Habitat loss and poaching have severely reduced their population."
        },
        {
            name: "Asian Elephant",
            number: "40000",
            info: "Asian elephants inhabit the forests and grasslands of Southeast Asia, including countries like India, Thailand, and Sri Lanka. They face threats from habitat loss, human-wildlife conflict, and illegal ivory trade."
        },
        {
            name: "Vaquita",
            number: "10",
            info: "The vaquita, a small porpoise, is native to the northern part of the Gulf of California in Mexico. It is critically endangered due to illegal fishing practices and bycatch, with only about 10 individuals remaining."
        },
        {
            name: "Hawksbill Turtle",
            number: "25000",
            info: "Hawksbill turtles are distributed throughout tropical coral reefs in the Atlantic, Pacific, and Indian Oceans. They are endangered due to poaching for their shells and habitat degradation."
        },
        {
            name: "Javan Rhino",
            number: "68",
            info: "The Javan rhino is found only in Ujung Kulon National Park in Java, Indonesia. Deforestation and human encroachment threaten their survival, leaving fewer than 70 individuals in the wild."
        },
        {
            name: "Sumatran Orangutan",
            number: "14800",
            info: "Sumatran orangutans inhabit the rainforests of Sumatra, Indonesia. Habitat destruction due to deforestation and palm oil plantations has significantly reduced their population."
        },
        {
            name: "Snow Leopard",
            number: "4000",
            info: "Snow leopards are found in mountainous regions across Central and South Asia. Habitat fragmentation, poaching, and climate change pose serious threats to their survival."
        },
        {
            name: "Blue Whale",
            number: "15000",
            info: "The blue whale, the largest animal on Earth, is found in all oceans except the Arctic. Overhunting in the 20th century has made them endangered, and they are currently protected under various international laws."
        }
    ]
};


app.use('/', express.static('public'));

app.get('/endangeredAnimals', (req, res) => {
    res.json(endangeredAnimals);
});

app.get('/endangeredAnimals/:animal', (req, res) => {
    console.log(req.params.animal);
    let user_animal = req.params.animal;
    let user_obj;
    for(let i = 0; i < endangeredAnimals.data.length; i++) {
        if(user_animal == endangeredAnimals.data[i].name) {
            user_obj = endangeredAnimals.data[i];
        }
    }
    console.log(user_obj);
    if(user_obj) {
        res.json(user_obj);
    } else {
        res.json({status: "info not present"});
    }
});

app.listen(3000, () => {
    console.log("app is listening at localhost:3000");
});